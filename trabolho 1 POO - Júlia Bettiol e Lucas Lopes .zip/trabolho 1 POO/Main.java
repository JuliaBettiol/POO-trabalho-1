import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {
    private Scanner sc;
    private GaragemLoc garagemLoc;
    private GaragemVag garagemVag;
    private int idTrem;
    private int idLoc;
    private int idVag;
    private Patio patio;

    public Main() {
        sc = new Scanner(System.in);
        garagemLoc = new GaragemLoc();
        garagemVag = new GaragemVag();
        patio = new Patio();
    }

    public void menuOpcoes() {
        int escolha = 0;
        do {
            System.out.println("Menu Opções:");
            System.out.println("1 - Criar um trem");
            System.out.println("2 - Editar um trem");
            System.out.println("3 - Listar todos os trens");
            System.out.println("4 - Desfazer um trem");
            System.out.println("5 - Salvar em um arquivo texto");
            System.out.println("6 - Carregar as configurações de um arquivo texto");
            System.out.println("7 - Fim.");

            escolha = sc.nextInt();
            switch (escolha) {
                case 1:
                    criaTrem();
                    break;
                case 2:
                    editaTrem();
                    break;
                case 3:
                    System.out.println(patio);
                    break;
                case 4:
                    System.out.println("digite o id do trem");
                    idTrem = sc.nextInt();
                    Trem t = patio.getTrem(idTrem);
                    desfazTrem(t);
                    System.out.println("trem removido");
                    break;
                case 5:
                    carregarArquivo();
                    break;
                case 6:
                    carregarArquivo();
                    break;
                case 7:
                    System.out.println("Finalizando o programa...");
                    break;
            }
        } while (escolha != 6);
    }

    private void carregarArquivo() {
    }

    public void criaTrem() {
        System.out.println("Digite o número identificador do trem a ser criado");
        idTrem = sc.nextInt();
        System.out.println(garagemLoc);
        System.out.println("Digite o número identificador da primeira locomotiva: ");
        idLoc = sc.nextInt();
        while (garagemLoc.getLocomotiva(idLoc) == null) {
            System.out.println("Locomotiva não encontrada. Digite um ID válido.");
            idLoc = sc.nextInt();
        }
        Locomotiva loc = garagemLoc.getLocomotiva(idLoc);
        Trem trem = new Trem(idTrem, loc);
        patio.addTrem(trem);
        garagemLoc.retira(idLoc);
        loc.setRef(trem);
        System.out.print(trem.toStrings());
        System.out.println(" adicionado ao pátio");
    }

    public void editaTrem() {
        System.out.println("Digite o número identificador do trem a ser editado:");
        idTrem = sc.nextInt();
        while (patio.getTrem(idTrem) == null) {
            System.out.println("Trem não encontrado. Digite um ID válido.");
            idTrem = sc.nextInt();
        }
        Trem t = patio.getTrem(idTrem);
        int escolhaTrem = 0;
        do {
                System.out.println("Escolha uma opção:");
                System.out.println("1 - Inserir uma locomotiva");
                System.out.println("2 - Inserir um vagão");
                System.out.println("3 - Remover o último elemento do trem");
                System.out.println("4 - Listar locomotivas livres ");
                System.out.println("5 - Listar vagões livres");
                System.out.println("6 - Encerrar a edição do trem");

            escolhaTrem = sc.nextInt();
            switch (escolhaTrem) {
                case 1:
                    System.out.println("digite o id da locomotiva: ");
                    idLoc = sc.nextInt();
                    while (garagemLoc.getLocomotiva(idLoc) == null) {
                        System.out.println("Locomotiva não encontrada. Digite um ID válido.");
                        idLoc = sc.nextInt();
                    }
                    Locomotiva l = garagemLoc.getLocomotiva(idLoc);
                    if (!t.engataLoc(l)) {
                        System.out.println("Não é possível inserir uma locomotiva");
                    } else {
                        garagemLoc.retira(idLoc);
                        l.setRef(t);
                        System.out.println("Locomotiva adicionada. " + t.toStrings());
                    }
                    break;
                case 2:
                    System.out.println("Digite o id do vagao");
                    idVag = sc.nextInt();
                    while (garagemVag.getVagao(idVag) == null) {
                        System.out.println("Vagao não encontrado. Digite um ID válido.");
                        idVag = sc.nextInt();
                    }
                    Vagao v = garagemVag.getVagao(idVag);
                    if (!t.engataVag(v)) {
                        System.out.println("Não é possível inserir um vagão.");
                    } else {
                        garagemVag.retiraVag(idVag);
                        v.setRef(t);
                        System.out.println("Vagão adicionado " + t.toStrings());
                    }
                    break;
                case 3:
                    if (t.qntVagoes() > 0) {
                        garagemVag.estaciona(t.desengataVag(t.getVagao()));
                        System.out.println("vagao removido: " + t.getVagao());
                    } else {
                        if (t.qntLocs() > 1) {
                            System.out.println("locomotiva removida: " + t.getLoc());
                            garagemLoc.estaciona(t.desengataLoc(t.getLoc()));
                        } else {
                            System.out.println("Trem so tem uma locomotiva");
                        }
                    }
                    break;
                case 4:
                    System.out.println(garagemLoc.toString());
                    break;
                case 5:
                    System.out.println(garagemVag.toString());
                    break;
            }
        } while (escolhaTrem != 6);
    }

    public void desfazTrem(Trem t) {
        for (int i = 0; i < t.qntVagoes(); i++) {
            t.desengataVag(t.getVagao());
        }
        for (int i = 0; i < t.qntLocs(); i++) {
            t.desengataLoc(t.getLoc());
        }
        patio.removeTrem(t);
    } 
}
//OLÁ SOR, ACABEI TENDO DIFICULDADES EM FAZER A PARTE DOS ARQUIVOS. CONSEGUI, MAS QUANDO JUNTA O CÓDIGO DA ERRO. PEÇO DESCULPAS. MAS AVALIA COM CARINHO!

   //public class Configuracoes {
   // private static final String ARQUIVO_CONFIGURACOES = "configuracoes.txt";
   // private static final int MaxDeVagoes = 0;
 //   private List<Locomotiva> locomotivas;
  //  public Configuracoes() {
  //      this.locomotivas = new ArrayList<>();
   // }
   // public void salvarArquivo() throws IOException {
       // File arquivo = new File(ARQUIVO_CONFIGURACOES);
       // if (!arquivo.exists()) {
      //      arquivo.createNewFile();
      //  }
     //   BufferedWriter escritor = new BufferedWriter(new FileWriter(arquivo));
     //   for (Locomotiva locomotiva : locomotivas) {
     //       escritor.write(locomotiva.getId() + "," + locomotiva.getPesoMax() + "," + locomotiva.getMaxVagoes() + "," + locomotiva.getId());
      //      escritor.newLine();
     //   }
     //   escritor.close();
    //}
  //  public void carregarConfiguracoes() throws IOException {
      //  File arquivo = new File(ARQUIVO_CONFIGURACOES);
        //if (!arquivo.exists()) {
       //     return;
      //  }
       // BufferedReader leitor = new BufferedReader(new FileReader(arquivo));
       // String linha;
       //while ((linha = leitor.readLine()) != null) {
          //  String[] dados = linha.split(",");
         //   int identificador = Integer.parseInt(dados[0]);
         //   double pesoMaximo = Double.parseDouble(dados[1]);
          //  int numeroMaximoDeVagoes = Integer.parseInt(dados[2]);
         //   int identificadorDoTrem = Integer.parseInt(dados[3]);
         //   double pesoMax;
         //   Object id;
         //   Locomotiva locomotiva = new Locomotiva(id, pesoMax, MaxDeVagoes, id);
         //  locomotivas.add(locomotiva);
       // }
     //   leitor.close();
   // }
  //  public List<Locomotiva> getLocomotivas() {
   //     return locomotivas;
   // }
  //  public void carregarArquivo() throws IOException {
    //    File arquivo = new File(ARQUIVO_CONFIGURACOES);
     //   if (!arquivo.exists()) {
     //       return;
     //   }
     //   BufferedReader leitor = new BufferedReader(new FileReader(arquivo));
      //  String linha;
      //  while ((linha = leitor.readLine()) != null) {
      //      String[] dados = linha.split(",");
      //      int identificador = Integer.parseInt(dados[0]);
       //     double pesoMaximo = Double.parseDouble(dados[1]);
       //     int numeroMaximoDeVagoes = Integer.parseInt(dados[2]);
       //     int identificadorDoTrem = Integer.parseInt(dados[3]);
      //      double pesoMax;
      //      int id;
      //      Locomotiva locomotiva = new Locomotiva(id, pesoMax, MaxVagoes);
      //      locomotivas.add(locomotiva);
     //   }
     //   leitor.close();
   // }
   // public List<Locomotiva> getLocomotivas() {
    //    return locomotivas;
  //  }
//}
