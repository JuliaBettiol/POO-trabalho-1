public class Locomotiva {
    private int id; //armazena id
    private double pesoMax; //armazena peso maximo
    private int maxVagoes; //armazena quantidade maxima de vagoes
    private Trem ref;

    public Locomotiva(int id, double pesoMax, int maxVagoes) { //construtor
        this.id = id;
        this.pesoMax = pesoMax;
        this.maxVagoes = maxVagoes;
        ref = null;
    }

    public Locomotiva(Object id2, double pesoMax2, int maxdevagoes, Object id3) {
    }

    public int getId() { //retorna id da locomotiva
        return id;
    }

    public double getPesoMax() { //retorna o peso maximo da locomotiva
        return pesoMax;
    }

    public int getMaxVagoes() { //retorna a quantidade maxima de vagoes na locomotiva
        return maxVagoes;
    }

    public void setRef(Trem trem) {
        ref = trem;
    }

    public void setmaxVagoes(int newMaxVagoes) {
        maxVagoes = newMaxVagoes;
    }

    @Override
    public String toString() {
        return "Locomotiva [id = " + id + ", pesoMax = " + pesoMax + ", maxVagoes = " + maxVagoes + ", ref = " + ref
                + "]";
    }

}
