import java.util.*;

public class GaragemLoc {
    private ArrayList<Locomotiva> locomotivas; //armazena locomotivas disponiveis
    private int numLocs;
    private Random rand;

    public GaragemLoc() { //construtor para criar instancia
        locomotivas = new ArrayList<Locomotiva>(); //nova lista vazia para quando criar uma garagem inicialmente nao tem locomotivas disponiveis 
        rand = new Random();
        for (int i = 0; i < 10; i++) { // gera 10 locomotivas com ids aleatorios
            int id = rand.nextInt(9000) + 1000;
            int pesoMax = i > 10 ? 3000 : 5000; // gera metade das locomotivas com capacidade de carregar 30 vagoes e
                                                // metade 50
            Locomotiva l = new Locomotiva(id, 3000, pesoMax / 100);
            locomotivas.add(l); //adicionar locomotiva na garagem

        }
        numLocs = 10;
    }

    public int getNumLocs() {
        return numLocs;
    }

    public void estaciona(Locomotiva l) {
        locomotivas.add(l);
        numLocs++;
    }

    public Locomotiva getLocomotiva(int idLoc) { // procura a locomotiva pelo id
        for (Locomotiva l : locomotivas) {
            if (l.getId() == idLoc) {
                return l;
            }
        }
        return null;
    }

    public Locomotiva retira(int idLoc) { // remove a locomotiva da garagem; utiliza o metodo de procurar pelo id
        if (getLocomotiva(idLoc) != null) {
            locomotivas.remove(getLocomotiva(idLoc));
            numLocs--;
            return getLocomotiva(idLoc);
        }
        return null;
    }

    public String toString() {
        String a = "Locomotivas livres:\n";
        for (Locomotiva l : locomotivas) {
            a += l.toString() + "\n";
        }
        return a;
    }
}