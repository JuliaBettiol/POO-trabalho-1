import java.util.*;

public class GaragemVag {
    private ArrayList<Vagao> vagoes; //armazena vagoes disponiveis
    private int numVags;
    private Random rand;

    public GaragemVag() { //construtor para criar instancias
        vagoes = new ArrayList<Vagao>(); //nova lista vazia para quando criar uma garagem inicialmente nao tem vagoes disponiveis 
        rand = new Random();
        for (int i = 0; i < 20; i++) { // gera 20 vagoes com ids aleatorios
            int id = rand.nextInt(9000) + 1000;
            int t = i > 10 ? 50 : 100; // gera metade dos vagoes com capacidade de 50t e metade 100t
            Vagao v = new Vagao(id, t);
            vagoes.add(v); //add vagao na garagem
        }
        numVags = 20;
    }

    public int getNumVags() {
        return numVags;
    }

    public void estaciona(Vagao v) {
        vagoes.add(v);
        numVags++;
    }

    public Vagao getVagao(int id) {
        for (Vagao v : vagoes) {
            if (v.getId() == id) {
                return v;
            }
        }
        return null;
    }

    public Vagao retiraVag(int id) { //remover vagao especifico na garagem
        Vagao v = getVagao(id);
        if (v != null) {
            vagoes.remove(v);
            numVags--;
            return v;
        }
        return null;
    }

    public String toString() {
        String a = "Vagões livres:\n";
        for (Vagao v : vagoes) {
            a += v.toString() + "\n";
        }
        return a;
    }
}
