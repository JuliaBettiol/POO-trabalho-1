public class Vagao {
    private int id;
    private double capacidadeCarga;
    private Trem ref;

    public Vagao(int id, int capacidadeCarga) {
        this.id = id;
        this.capacidadeCarga = capacidadeCarga;
        ref = null;
    }

    public int getId() {
        return id;
    }

    public double getcapacidadeCarga() {
        return capacidadeCarga;
    }

    public void setRef(Trem trem) {
        ref = trem;
    }

    @Override
    public String toString() {
        return "Vagao [id  = " + id + ", capacidadeCarga = " + capacidadeCarga + ", ref = " + ref + "]";
    }
}