import java.util.*;

public class Trem {
    private ArrayList<Locomotiva> locomotivas; //lista que representa locomotivas na composicao
    private ArrayList<Vagao> vagoes; //lista que representa vagoes na composicao
    private int id; //identificador da composicao
    private double capacLocs;
    private int qntVagoes;
    private int qntLocs;

    public Trem(int id, Locomotiva l) { //parametro
        locomotivas = new ArrayList<Locomotiva>();
        vagoes = new ArrayList<Vagao>();
        this.id = id;
        engataLoc(l);
        qntLocs = 1;
        qntVagoes = 0;
        capacLocs = l.getMaxVagoes();
    }

    public int getId() {
        return id;
    }

    public int qntLocs() { //n locomotivas 
        return qntLocs;
    }

    public Locomotiva getLoc() { // retorna ultima
        return locomotivas.get(locomotivas.size() - 1);
    }


    public int qntVagoes() { //n de vagoes 
        return qntVagoes;
    }

    public Vagao getVagao() { // retorna ultima
        if (vagoes.size() > 0) {
            return vagoes.get(vagoes.size() - 1);
        }
        return null;
    }

    public boolean engataLoc(Locomotiva l) { //engatar locomotiva a composicao
        if (vagoes.size() == 0) {
            locomotivas.add(l);
            qntLocs++;
            capacLocs = (capacLocs + l.getMaxVagoes()) * 0.9; //reduz em 10% para proxima locomotiva
            return true;
        }
        return false;
    }

    public boolean engataVag(Vagao v) {
        if (capacLocs > 1) {
            vagoes.add(v);
            qntVagoes++;
            capacLocs--;
            return true;
        }
        return false;

    }

    public Locomotiva desengataLoc(Locomotiva l) { //desengatar ultima locomotiva
        if (vagoes.isEmpty() && locomotivas.size() > 1) { // verificando se nao tem nenhum vagao ou a se o trem so tem
                                                          // uma locomotiva
            locomotivas.remove(l);
            l.setRef(null);
            qntLocs--;
            capacLocs = (capacLocs - l.getMaxVagoes()) * 1.1;
            return l;
        }
        return null;
    }

    public Vagao desengataVag(Vagao v) { //desengatar ultimo vagao
        if (vagoes.isEmpty()) { // verificando se tem algum vagao p tirar
            vagoes.remove(v);
            v.setRef(null);
            qntVagoes--;
            capacLocs++;
            return v;
        }
        return null;
    }

    public String toStrings() {
        String a = "Trem [id=" + id + ", qntVagoes=" + qntVagoes + ", qntLocs=" + qntLocs + "\nLocomotivas:\n"
                + locomotivasString();
        if (!vagoes.isEmpty()) {
            a += "Vagoes:\n" + vagoesString();
        }
        return a;
    }

    public String locomotivasString() {
        String a = "";
        for (Locomotiva l : locomotivas) {
            a += l.toString() + "\n";
        }
        return a;
    }

    public String vagoesString() {
        String a = "";
        for (Vagao l : vagoes) {
            a += l.toString() + "\n";
        }
        return a;
    }

}