import java.util.*;

public class Patio {
    private ArrayList<Trem> trens; //armazena composicoes de trens no patio
    private int numTrens;

    public Patio() { //construtor para criar uma instancia
        trens = new ArrayList<Trem>(); //nova lista vazia, quando é criado nao tem composicao
        numTrens = 0;
    }

    public int numTrens() {
        return numTrens;
    }

    public Trem getTrem(int id) {
        for (Trem t : trens) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    public void addTrem(Trem trem) { //add composicao no patio
        trens.add(trem);
    }

    public Trem removeTrem(Trem t) { //remover composicao especifica
        if (t != null) {
            trens.remove(t);
            numTrens--;
            return t;
        }
        return null;
    }

    public String toString() {
        String a = "Trens:\n";
        for (Trem t : trens) {
            a += t.toString() + "\n";
        }
        a += numTrens + "trens criados";
        return a;

    }

}