public class App {
    public static void main(String[] args) throws Exception {
        Main in = new Main();
        in.menuOpcoes();
    }
}
